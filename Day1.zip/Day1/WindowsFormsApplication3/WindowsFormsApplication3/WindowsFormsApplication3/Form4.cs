﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApplication3
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            DriveInfo[] drv =  DriveInfo.GetDrives();

            foreach (DriveInfo d in drv)
            {
                comboBox1.Items.Add(d.Name);
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string drivename = comboBox1.SelectedItem.ToString();
            
            DriveInfo d = new DriveInfo(drivename);
            label4.Text =( d.TotalSize/(1024 * 1024*1024)).ToString();
            label5.Text = (d.TotalFreeSpace / (1024 * 1024 * 1024)).ToString();

        }
    }
}
