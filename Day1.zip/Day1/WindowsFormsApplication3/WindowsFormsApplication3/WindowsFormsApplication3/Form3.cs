﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filename = textBox1.Text;

            if (Directory.Exists(filename))
            {
                MessageBox.Show("directory already exist...");
            }
            else
            {
                Directory.CreateDirectory(filename);
                MessageBox.Show("directory created....");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //string filename = textBox1.Text;

            //if (Directory.Exists(filename))
            //{
            //    Directory.Delete(filename);
            //    MessageBox.Show("Directory deleted...");
            //}
            //else
            //{
            //    MessageBox.Show("no file available.....");
            //}

            string filename = textBox1.Text;
            DirectoryInfo dir = new DirectoryInfo(filename);
            if(dir.Exists)
            {
                dir.Delete();
                MessageBox.Show("deleted...");
            }
            else
            {
                MessageBox.Show("no directory found...");
            }
        }
    }
}
