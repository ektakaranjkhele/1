﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApplication3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filename = textBox1.Text;

            FileInfo f = new FileInfo(filename);

            if(f.Exists)
            {
                MessageBox.Show("already exist...");
            }
            else
            {
                f.Create();
                MessageBox.Show("created...");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string filename = textBox1.Text;

            FileInfo f = new FileInfo(filename);
            if(f.Exists)
            {
                f.Delete();
                MessageBox.Show("deleted..,");
            }
            else
            {
                MessageBox.Show("no file found..");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
