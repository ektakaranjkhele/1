﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filename = textBox1.Text;

            if(File.Exists(filename))
            {
                MessageBox.Show("file already exist...");
            }
            else
            {
                File.Create(filename);
                MessageBox.Show("file created....");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string filename = textBox1.Text;

            if (File.Exists(filename))
            {
                File.Delete(filename);
                MessageBox.Show("file deleted...");
            }
            else
            {                
                MessageBox.Show("no file available.....");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            string filename = textBox1.Text;
            if(File.Exists(filename))
            {
                File.Move(filename, "E:\\mayur\\sample.txt");
                //File.Move(filename, @"E:\mayur\sample.txt");
                MessageBox.Show("done..");
            }
            else
            {
                MessageBox.Show("sorry... no file found..");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label2.Text = File.GetCreationTime("e:\\mayur\\sample.txt").ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
