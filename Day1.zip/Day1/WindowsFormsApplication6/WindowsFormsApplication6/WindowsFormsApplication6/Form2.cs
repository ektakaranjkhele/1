﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Threading;

namespace WindowsFormsApplication6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        Thread t1, t2;
        private void button1_Click(object sender, EventArgs e)
        {
            //normal flow
            //Asc();
            //Des();

            //ListBox.CheckForIllegalCrossThreadCalls = false;
            //Button.CheckForIllegalCrossThreadCalls = false;
            //Form.CheckForIllegalCrossThreadCalls = false;

            //using threading
             t1 = new Thread(Asc);
             t2 = new Thread(Des);

            t1.Start();
            t2.Start();
        }

        public void Asc()
        {
            for (int i = 1; i <= 10; i++)
            {
                listBox1.Items.Add(i);
                Thread.Sleep(1000);
                if(i == 3)
                {
                    t2.Join();
                    //t1.Suspend();
                }
                //some database operations are performed... or some IO task op.
            }
        }

        public void Des()
        {
            for (int j = 10; j >= 1; j--)
            {
                listBox2.Items.Add(j);
                Thread.Sleep(1000);

                //if(j==4)
                //{
                //    //t1.Resume();
                //}

            }
        }
    }
}
