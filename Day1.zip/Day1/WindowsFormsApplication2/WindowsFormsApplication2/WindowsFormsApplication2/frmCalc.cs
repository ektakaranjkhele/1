﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class frmCalc : Form
    {
        public frmCalc()
        {
            InitializeComponent();
        }

        int no1, no2;
        string op;

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + (sender as Button).Text;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            no1 = Convert.ToInt32(textBox1.Text);
            textBox1.Text = "";
            op = (sender as Button).Text;
        }

        

        private void button15_Click(object sender, EventArgs e)
        {
            no2 = Convert.ToInt32(textBox1.Text);
            switch (op)
            {
                case "+":
                    textBox1.Text = (no1 + no2).ToString();
                    break;
                case "-":
                    textBox1.Text = (no1 - no2).ToString();
                    break;
                case "/":
                    textBox1.Text = (no1 / no2).ToString();
                    break;
                case "*":
                    textBox1.Text = (no1 * no2).ToString();
                    break;

                default:
                    break;
            }
        }
    }
}
