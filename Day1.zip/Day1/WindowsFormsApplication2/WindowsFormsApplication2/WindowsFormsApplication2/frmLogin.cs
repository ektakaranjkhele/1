﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            if(txtname.Text == "admin" && txtpwd.Text == "admin")
            {
                MessageBox.Show("login successful....");
            }
            else
            {
                MessageBox.Show("sorry... invalid username/password...");
            }
        }
    }
}
