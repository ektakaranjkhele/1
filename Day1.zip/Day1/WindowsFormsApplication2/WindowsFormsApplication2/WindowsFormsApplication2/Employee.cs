﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2
{
    public  class Employee
    {
        protected int id;
        protected String name;
        protected double salary;

        protected double hra;
        protected double pf;
        protected double grosssal;
        protected double netsal;

        private static int EmployeeCount = 0;//static member variable


        public Employee()
        {
            id = 0;
            name = "";
            salary = 0.0;
            EmployeeCount += 1;

        }

        public Employee(int id, String name, double salary)
        {
            this.id = id;
            this.name = name;
            this.salary = salary;
            EmployeeCount += 1;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public String Name
        {
            get { return name; }
            set { name = value; }
        }

        public double Salary
        {
            get { return salary; }
            set
            {
                if (value > 0)
                {
                    salary = value;
                }
                else
                {
                    salary = 100000;
                }
            }

        }
        public double HRA
        {
            get { return hra = 25000; }
        }

        public double PF
        {
            get { return pf = (salary * 12) / 100; }
        }


        public double NetSalary
        {
            get { return netsal; } 
        }

        public double GrossSalary
        {
            get { return grosssal; }
        }

        //Static method
        public static void ShowCount()
        {
            Console.WriteLine("\nTotal number of Employees = " + EmployeeCount);
        }

       


        //Salary calculation
        public void  CalculateSalary()
        {
            grosssal = salary + HRA;
            netsal = grosssal - PF;
        }


        public virtual void ShowDetails()
        {
            Console.WriteLine("\nEmployee Id = " + Id + "\nEmployee Name = " + Name + "\nBasic Salary = " + Salary + "\nGross salary " + grosssal + "\nnetsalary = " + netsal);
        }


        public override string ToString()
        {
            return "Employee Id = " + Id + "\nEmployee Name = " + Name + "\nBasic Salary = " + Salary + "\nGross salary " + grosssal + "\nnetsalary = " + netsal;
        }
    }
}



