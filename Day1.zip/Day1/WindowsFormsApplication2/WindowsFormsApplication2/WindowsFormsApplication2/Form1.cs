﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //event handler
        private void btnclick_Click(object sender, EventArgs e)
        {
            lblmsg.Text = "hello world....";
            //MessageBox.Show("welcome to windows application...");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblmsg.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] str = { "Pune","Mumbai","Delhi","Kolhapur","Nashik"};

            foreach (string s in str)
            {
                listBox1.Items.Add(s);
                comboBox1.Items.Add(s);
            }

            //listBox1.Items.Add("Pune");
            //listBox1.Items.Add("Mumbai");
            //listBox1.Items.Add("Delhi");
            //listBox1.Items.Add("Kolhapur");
            //listBox1.Items.Add("Nashik");

            //comboBox1.Items.Add("Pune");
            //comboBox1.Items.Add("Mumbai");
            //comboBox1.Items.Add("Delhi");
            //comboBox1.Items.Add("Kolhapur");
            //comboBox1.Items.Add("Nashik");
        }
    }
}
