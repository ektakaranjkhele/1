﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;


namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        FileStream fs;
        StreamWriter sw;        //Write(), WriteLine()
        StreamReader sr;        //Read(), ReadLine(), ReadToEnd()

        private void button1_Click(object sender, EventArgs e)
        {
            fs = new FileStream(@"e:\sample.txt", FileMode.Append, FileAccess.Write);
            sw = new StreamWriter(fs);

            sw.WriteLine(textBox1.Text);
            MessageBox.Show("done");
            sw.Close();
            fs.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            fs = new FileStream(@"e:\sample.txt", FileMode.Open, FileAccess.Read);
            sr = new StreamReader(fs);

            richTextBox1.Text =  sr.ReadToEnd();

            sr.Close();
            fs.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            fs = new FileStream(@"e:\sample.txt", FileMode.Open, FileAccess.Read);
            sr = new StreamReader(fs);

            richTextBox1.Text = sr.ReadLine();

            sr.Close();
            fs.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            fs = new FileStream(@"e:\sample.txt", FileMode.Open, FileAccess.Read);
            sr = new StreamReader(fs);

            //code to read without special charactors
            while (! sr.EndOfStream)
            {
                char c = Convert.ToChar(sr.Read());

                if (c == '%' || c == '#' || c == '$')
                {
                    continue;
                }
                else
                {
                    richTextBox1.Text += c.ToString();
                }
            }
            sr.Close();
            fs.Close();
        }
    }
}
